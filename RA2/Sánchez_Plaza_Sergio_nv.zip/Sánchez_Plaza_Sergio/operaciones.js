function tablaMultiplicar(numero) {

    if(numero >= 0 && numero <= 10){

        const tabla = document.getElementById("tablaMultiplicar");
        let tablaMultiplicar = `<h2>Tabla de multiplicar del ${numero}</h2>`;
        tablaMultiplicar += `<table>`;
        tablaMultiplicar += `<tr>
                                <th> Multiplicacion</th>
                                <th>Resultado</th>
                                <th>Bucle</th>
                            </tr>`;

        for(let i = 0; i<=10;i++){

            tablaMultiplicar += `<tr><td>${numero} * ${i}</td> <td>${numero * i}</td><td>For</td></tr>`;
        }

        tablaMultiplicar += `</table>`;
        tabla.innerHTML = tablaMultiplicar;

    }else{

        alert('El numero introducido debe estar entre 0 y 10');
        document.getElementById("numero").value= '';

    }  

}

function tablaSuma(numero){

    if(numero >= 0 && numero <= 10){

        let tabla = document.getElementById('tablaSumar');
        let tablaSumar = `<h2>Tabla de Sumas del ${numero}</h2>`;
        tablaSumar += `<table>`;
        tablaSumar += `<tr>
                                <th>Suma</th>
                                <th>Resultado</th>
                                <th>Bucle</th>
                            <tr>`;

        let contador = 0;

        while(contador <=10){

            tablaSumar += `<tr><td>${numero} + ${contador}</td> <td>${numero + contador}</td><td>While</td></tr>`;
            contador++;
        }

        tablaSumar += `</table>`;
        tabla.innerHTML = tablaSumar;

    }else{

        alert('El numero introducido debe estar entre 0 y 10');
        document.getElementById("numero").value= '';

    } 

}

function tablaDividir(numero){

    if(numero >= 0 && numero <= 10){

        let tabla = document.getElementById('tablaDividir');
        let tablaDividir = `<h2>Tabla de Dividir del ${numero}</h2>`;
        tablaDividir += `<table>`;
        tablaDividir += `<tr>
                                <th>Division</th>
                                <th>Resultado</th>
                                <th>Bucle</th>
                            </tr>`;

        let contador = numero;

        do{

            tablaDividir += `<tr><td>${contador} / ${numero}</td> <td>${contador / numero}</td><td>Do While</td></tr>`;
            contador+=numero;

        }while(contador <= numero * 10);

        tablaDividir += `</table>`;
        tabla.innerHTML = tablaDividir;

    }else{

        alert('El numero introducido debe estar entre 0 y 10');
        document.getElementById("numero").value= '';

    } 

}